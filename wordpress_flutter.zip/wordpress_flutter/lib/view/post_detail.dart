import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:html_unescape/html_unescape.dart';
import 'package:marquee/marquee.dart';
import 'package:wordpress_flutter/model/post_model.dart';
import 'package:html/dom.dart' as dom;

class PostDetailPage extends StatelessWidget {
  const PostDetailPage({
    Key? key,
    required this.postData,
  }) : super(key: key);
  final PostModel postData;
  @override
  Widget build(BuildContext context) {
    var unescape = HtmlUnescape();
    var title = unescape.convert(postData.title!.rendered.toString());
    print('title: ' + title);

    final AppBar appBar = AppBar();
    final Size size = MediaQuery.of(context).size;
    final double realHeight = size.height -
        appBar.preferredSize.height -
        MediaQuery.of(context).padding.top -
        MediaQuery.of(context).padding.bottom;
    //print(postData.content!.rendered.toString());
    return Scaffold(
      appBar: AppBar(
        leadingWidth: size.width * .075,
        title: SizedBox(
          width: size.width * .85,
          height: AppBar().preferredSize.height,
          child: Center(
            child: Marquee(
              text: title,
              key: Key("_$postData.title!.rendered.toString()"),
              style: GoogleFonts.ubuntuMono(
                fontWeight: FontWeight.bold,
              ),
              scrollAxis: Axis.horizontal,
              crossAxisAlignment: CrossAxisAlignment.center,
              blankSpace: 40.0,
              velocity: 100.0,
              pauseAfterRound: const Duration(seconds: 2),
              showFadingOnlyWhenScrolling: true,
              fadingEdgeStartFraction: 0.1,
              fadingEdgeEndFraction: 0.1,
              numberOfRounds: 13,
              startPadding: 10.0,
              accelerationDuration: const Duration(seconds: 1),
              accelerationCurve: Curves.linear,
              decelerationDuration: const Duration(milliseconds: 50),
              decelerationCurve: Curves.easeOut,
              textDirection: TextDirection.ltr,
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: size.width * .05),
            // margin: EdgeInsets.all(size.width * .025),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(8)),
            width: size.width,
            height: realHeight,
            child: SingleChildScrollView(
              child: Html(
                onLinkTap: (String? url, RenderContext ctx, Map<String, String> attributes, dom.Element? element) {
                  showModalBottomSheet(
                      context: context,
                      builder: (context) {
                        InAppWebViewController? webViewController;
                        InAppWebViewGroupOptions options = InAppWebViewGroupOptions(
                          crossPlatform:
                              InAppWebViewOptions(verticalScrollBarEnabled: false, userAgent: "Accept-Language: tr-TR"),
                          ios: IOSInAppWebViewOptions(
                            disableLongPressContextMenuOnLinks: true,
                            allowsLinkPreview: false,
                            alwaysBounceVertical: false,
                            disallowOverScroll: true,
                          ),
                          android: AndroidInAppWebViewOptions(
                            overScrollMode: AndroidOverScrollMode.OVER_SCROLL_NEVER,
                          ),
                        );
                        return SizedBox(
                          height: realHeight * .85,
                          width: size.width,
                          child: InAppWebView(
                            initialUrlRequest: URLRequest(
                              url: Uri.parse(url!),
                            ),
                            onWebViewCreated: (InAppWebViewController controller) {
                              webViewController = controller;
                            },
                            initialOptions: options,
                          ),
                        );
                      });
                },
                data: postData.content!.rendered.toString(),
                style: {
                  "p": Style(
                    padding: const EdgeInsets.only(left: 10),
                    fontWeight: FontWeight.bold,
                  ),
                  "ol": Style(
                    border: Border.all(
                      color: Colors.cyanAccent,
                      width: 2,
                    ),
                  ),
                  "ul": Style(
                    fontWeight: FontWeight.bold,
                  ),
                  "li": Style(
                    listStyleType: ListStyleType.LOWER_ALPHA,
                  ),
                  "pre,code": Style(
                    whiteSpace: WhiteSpace.NORMAL,
                    padding: const EdgeInsets.all(5),
                    border: Border.all(
                      color: Colors.grey.shade300,
                      style: BorderStyle.solid,
                      width: 2,
                    ),
                  )
                },
              ),
            ),
          )
        ],
      ),
    );
  }
}
