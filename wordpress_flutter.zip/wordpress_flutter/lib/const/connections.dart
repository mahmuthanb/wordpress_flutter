String url = "https://www.mahmuthan.com";
String jsonEndpoint = "/wp-json/wp/v2";
String restAPI = url + jsonEndpoint;
