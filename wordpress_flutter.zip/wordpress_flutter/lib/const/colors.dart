import 'package:flutter/material.dart';

Color shimmerBase = Colors.grey.shade100;
Color shimmerHighlighted = Colors.grey.shade200;
